export const useWarmUpBrowser = () => {
  return;
};
